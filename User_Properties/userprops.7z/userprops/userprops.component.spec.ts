import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserpropsComponent } from './userprops.component';

describe('UserpropsComponent', () => {
  let component: UserpropsComponent;
  let fixture: ComponentFixture<UserpropsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserpropsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserpropsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
