import { Component, OnInit } from '@angular/core';
import { Property } from "src/app/home/User-shared/Property.Model";
import { Router } from "@angular/router";
import { PropertyService } from "src/app/home/Property-shared/property.service";
import { UserProfileService } from "src/app/home/User-shared/user-profile.service";

@Component({
  selector: 'app-userprops',
  templateUrl: './userprops.component.html',
  styleUrls: ['./userprops.component.css']
})
export class UserpropsComponent implements OnInit {
  propList = new Array<Property>();
  constructor(public userservice:UserProfileService, private router: Router) { }

  ngOnInit() {
    
  }

  Oncomplete(val: number) {
    this.router.navigate(['/home/propdetails',{val}])
  }

}
